#####################################

-- CAPSTONE PROJECT USING MySQL -- 

#####################################

# Task 1: Displaying Full Names of Actors 

SELECT CONCAT(first_name, ' ', last_name) AS ActorFullName FROM actor;

# Task 2.1: Count of Actors with the Same First Name

SELECT first_name, COUNT(*) AS NameCount FROM actor GROUP BY first_name ORDER BY NameCount DESC;

# Task 2.2: Actors with Unique First Names

SELECT first_name FROM (SELECT first_name, COUNT(*) AS NameCount FROM actor GROUP BY first_name) AS NameCounts WHERE NameCount = 1;

# Task 3.1: Count of Actors with the Same Last Name

SELECT last_name, COUNT(*) AS NameCount FROM actor GROUP BY last_name ORDER BY NameCount DESC;

# Task 3.2: Unique Last Names of Actors

SELECT DISTINCT last_name FROM actor;

# Task 4.1: Movies with 'R' Rating

SELECT * FROM film WHERE rating = 'R';

# Task 4.2: Movies without 'R' Rating

SELECT * FROM film WHERE rating != 'R';

# Task 4.3: Movies with 'G' or 'PG' Rating

SELECT * FROM film WHERE rating = 'G' OR rating = 'PG';

# Task 5.1: Movies with Replacement Cost Less Than or Equal to 11

SELECT title, replacement_cost FROM film WHERE replacement_cost <= 11;

# Task 5.2: Movies with Replacement Cost Between 11 and 20

SELECT title, replacement_cost FROM film WHERE replacement_cost BETWEEN 11 AND 20;

# Task 5.3: Movies Ordered by Replacement Cost in Descending Order

SELECT title, replacement_cost FROM film ORDER BY replacement_cost DESC;

# Task 6: Top 3 Movies with the Most Actors

SELECT f.title, COUNT(fa.actor_id) AS ActorCount FROM film AS f
JOIN film_actor AS fa ON f.film_id = fa.film_id GROUP BY f.title ORDER BY ActorCount DESC LIMIT 3;

# Task 7: Movies Starting with 'K' and 'Q'

SELECT title FROM film WHERE title LIKE 'K%' OR title LIKE 'Q%' ORDER BY title;

# Task 8: Actors in the Film 'Agent Truman'

SELECT a.first_name, a.last_name FROM actor AS a JOIN film_actor AS fa ON a.actor_id = fa.actor_id
JOIN film AS f ON fa.film_id = f.film_id WHERE f.title = 'Agent Truman';

# Task 9: Family Movies for Promotion

SELECT f.title, c.name AS category FROM film AS f JOIN film_category AS fc ON f.film_id = fc.film_id
JOIN category AS c ON fc.category_id = c.category_id WHERE c.name = 'Family';

# Task 10.1: Movies by Rating with Rental Rate Statistics

SELECT f.rating,
       MAX(f.rental_rate) AS MaxRentalRate,
       MIN(f.rental_rate) AS MinRentalRate,
       AVG(f.rental_rate) AS AvgRentalRate
FROM film AS f GROUP BY f.rating ORDER BY AvgRentalRate DESC;

# Task 10.2: Movies by Rental Frequency

SELECT f.title,
       COUNT(r.rental_id) AS RentalFrequency
FROM film AS f JOIN inventory AS i ON f.film_id = i.film_id
JOIN rental AS r ON i.inventory_id = r.inventory_id GROUP BY f.title ORDER BY RentalFrequency DESC;

# Task 11: Film Categories with Significant Cost-Rental Differences

SELECT c.name AS category,
       AVG(f.replacement_cost - f.rental_rate) AS CostDifference
FROM film AS f JOIN film_category AS fc ON f.film_id = fc.film_id
JOIN category AS c ON fc.category_id = c.category_id GROUP BY c.name HAVING CostDifference > 15;

# Task 12: Film Categories with More Than 70 Movies

SELECT c.name AS category,
       COUNT(f.film_id) AS MovieCount
FROM category AS c JOIN film_category AS fc ON c.category_id = fc.category_id
JOIN film AS f ON fc.film_id = f.film_id GROUP BY c.name HAVING MovieCount > 70;
